package router

import "fmt"

func Router() {
	//router := mux.NewRouter
	fmt.Println("This is ")

	//router.HandleFunc(" /", controller.HomeHandler).Methods("GET")
	//router.HandleFunc("/api/movies", controller.GetAllMovies).Methods("GET")
	//router.HandleFunc("/api/movie", controller.CreateMovie).Methods("POST")
	//router.HandleFunc("/api/movie/{id}", controller.MarkAsWatched).Methods("PUT")
	//router.HandleFunc("/api/movie/{id}", controller.DeleteAMovie).Methods("DELETE")
	//router.HandleFunc("/api/deleteallmovie", controller.DeleteAllMovie).Methods("DELETE")

}
