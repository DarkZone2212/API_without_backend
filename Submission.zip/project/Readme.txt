Here is an API and Application of a student details 

Step 1: run go run main.go  // to run the code 

to check if server is connected or not so to check that you can go to the browser and search - http://localhost:8000/
(If API is then API is running )

to check the CRUD operations working properly 
In VS code download extension thunder code 

you can check there 

http://localhost:8000/   main page                                      // GET Method 
http://localhost:8000/students   to access data                     //GET Method 
http://localhost:8000/student/{id}   to get particular id detail   GET Method 



http://localhost:8000/student   to add ne data without ID as ID is autiomatic available // its a POST operation

http://localhost:8000/student{id }   to update // its a PUT operation

http://localhost:8000/student{id}   Delete selected id  // its a DELETE operation





 
 
