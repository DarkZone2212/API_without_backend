package main

import (
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"net/http"
	"strconv"
	"time"

	"github.com/gorilla/mux"
)

type Student struct {
	StudentId string `json:"id"`
	Name      string `json:"sname"`
	Fname     string `json:"fname"`
	Mname     string `json:"mname"`
	Age       int    `json:"age"`
}

// fake DB
var students []Student

func main() {
	fmt.Println("Building API")
	r := mux.NewRouter()
	// seeding

	students = append(students, Student{StudentId: "2",
		Name:  "Darshan",
		Fname: "Shailendra Patni",
		Mname: "Barkha Patni",
		Age:   22,
	})
	students = append(students, Student{
		StudentId: "31",
		Name:      "Rohit",
		Fname:     "abc",
		Mname:     "xyz",
		Age:       10,
	})

	r.HandleFunc("/", homeServer).Methods("GET")
	r.HandleFunc("/students", getAllStudent).Methods("GET")
	r.HandleFunc("/student/{id}", getOneStudentDetail).Methods("GET")
	r.HandleFunc("/student", createNewStudent).Methods("POST")
	r.HandleFunc("/student/{id}", updateStudent).Methods("PUT")
	r.HandleFunc("/student/{id}", deleteStudent).Methods("DELETE")

	log.Fatal(http.ListenAndServe(":8000", r))

}

func homeServer(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("<h1>API</h1>"))
}

func getOneStudentDetail(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Details of All Students")
	w.Header().Set("Content-type", "application/json")

	params := mux.Vars(r)

	for _, student := range students {
		if student.StudentId == params["id"] {
			json.NewEncoder(w).Encode(students)
			return
		}
	}
}

func getAllStudent(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Details of All Students")
	w.Header().Set("Content-type", "application/json")

	json.NewEncoder(w).Encode(students)
}

func createNewStudent(w http.ResponseWriter, r *http.Request) {
	fmt.Println("create new student")
	w.Header().Set("Content-type", "application/json")

	if r.Body == nil {
		json.NewEncoder(w).Encode("please send some data")
	}

	// what about - {}

	var student Student
	_ = json.NewDecoder(r.Body).Decode(&student)

	//generate unique id. string
	//append course into courses

	rand.Seed(time.Now().UnixNano())
	student.StudentId = strconv.Itoa(rand.Intn(100))
	students = append(students, student)
	json.NewEncoder(w).Encode(student)
	return
}

func updateStudent(w http.ResponseWriter, r *http.Request) {
	fmt.Println("update student detail")
	w.Header().Set("Content-type", "application/json")

	params := mux.Vars(r)

	for index, student := range students {
		if student.StudentId == params["id"] {
			students = append(students[:index], students[index+1:]...)
			var student Student
			_ = json.NewDecoder(r.Body).Decode(&student)
			student.StudentId = params["id"]
			students = append(students, student)
			json.NewEncoder(w).Encode(student)
			return
		}
	}
}

func deleteStudent(w http.ResponseWriter, r *http.Request) {
	fmt.Println("delete student detail")
	w.Header().Set("Content-type", "application/json")

	params := mux.Vars(r)

	for index, student := range students {
		if student.StudentId == params["id"] {
			students = append(students[:index], students[index+1:]...)
			break
		}

	}
}
